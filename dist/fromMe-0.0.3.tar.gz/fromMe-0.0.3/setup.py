from setuptools import setup, find_packages
#import json

#with open("gitinfo.txt", 'r') as fj:	gitinfo = json.load(fj)

setup(
    name='fromMe',
    version="0.0.3",
    packages=find_packages(),
)
