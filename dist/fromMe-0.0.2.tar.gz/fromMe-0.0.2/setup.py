from setuptools import setup, find_packages
import json

with open("gitinfo.txt") as fj:
    gitinfo = json.load(fj)

setup(
    name='fromMe',
    version=gitinfo["version"],
    packages=find_packages(),
)
